@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Input Marks - {{ $examSession->name }}</h2>
    
    <form action="{{ route('marks.store', $examSession) }}" method="POST">
        @csrf
        <table class="table">
            <thead>
                <tr>
                    <th>Student</th>
                    @foreach($subjects as $subject)
                        <th>{{ $subject->name }}</th>
                    @endforeach
                </tr>
            </thead>
            <tbody>
                @foreach($students as $student)
                    <tr>
                        <td>{{ $student->name }}</td>
                        @foreach($subjects as $subject)
                            <td>
                                <input type="number" 
                                       name="marks[{{ $student->id }}_{{ $subject->id }}][marks_obtained]" 
                                       class="form-control"
                                       min="0"
                                       max="100"
                                       value="{{ old("marks.{$student->id}_{$subject->id}.marks_obtained") }}">
                                <input type="hidden" 
                                       name="marks[{{ $student->id }}_{{ $subject->id }}][student_id]" 
                                       value="{{ $student->id }}">
                                <input type="hidden" 
                                       name="marks[{{ $student->id }}_{{ $subject->id }}][subject_id]" 
                                       value="{{ $subject->id }}">
                            </td>
                        @endforeach
                    </tr>
                @endforeach
            </tbody>
        </table>
        <button type="submit" class="btn btn-primary">Save Marks</button>
    </form>
</div>
@endsection 