@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">Edit Grade</h5>
        </div>
        <div class="card-body">
            <form action="{{ route('grades.update', $grade) }}" method="POST">
                @csrf
                @method('PUT')
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Grade Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control @error('name') is-invalid @enderror" 
                               id="name" name="name" value="{{ old('name', $grade->name) }}" required>
                        @error('name')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6">
                        <label for="point" class="form-label">Grade Point <span class="text-danger">*</span></label>
                        <input type="number" step="0.01" class="form-control @error('point') is-invalid @enderror" 
                               id="point" name="point" value="{{ old('point', $grade->point) }}" required>
                        @error('point')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6">
                        <label for="mark_from" class="form-label">Mark From <span class="text-danger">*</span></label>
                        <input type="number" class="form-control @error('mark_from') is-invalid @enderror" 
                               id="mark_from" name="mark_from" value="{{ old('mark_from', $grade->mark_from) }}" required>
                        @error('mark_from')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-md-6">
                        <label for="mark_to" class="form-label">Mark To <span class="text-danger">*</span></label>
                        <input type="number" class="form-control @error('mark_to') is-invalid @enderror" 
                               id="mark_to" name="mark_to" value="{{ old('mark_to', $grade->mark_to) }}" required>
                        @error('mark_to')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="col-12">
                        <label for="comment" class="form-label">Comment</label>
                        <input type="text" class="form-control @error('comment') is-invalid @enderror" 
                               id="comment" name="comment" value="{{ old('comment', $grade->comment) }}">
                        @error('comment')
                            <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <div class="mt-4">
                    <a href="{{ route('grades.index') }}" class="btn btn-secondary">Cancel</a>
                    <button type="submit" class="btn btn-primary">Update Grade</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
