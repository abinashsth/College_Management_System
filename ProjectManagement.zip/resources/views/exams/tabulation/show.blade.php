@extends('layouts.app')

@section('content')
<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Tabulation Sheet</h5>
                <div>
                    <a href="{{ route('tabulation.index') }}" class="btn btn-secondary">Back</a>
                    <button onclick="window.print()" class="btn btn-primary">Print</button>
                </div>
            </div>
        </div>
        <div class="card-body">
            <div class="mb-4">
                <h6>Exam: {{ $exam->name }}</h6>
                <h6>Class: {{ $class->name }}</h6>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Roll No</th>
                            <th>Student Name</th>
                            @foreach($subjects as $subject)
                                <th>{{ $subject->name }}<br>({{ $subject->full_marks }})</th>
                            @endforeach
                            <th>Total</th>
                            <th>Average</th>
                            <th>Grade</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($students as $student)
                            <tr>
                                <td>{{ $student->roll_number }}</td>
                                <td>{{ $student->name }}</td>
                                @php
                                    $total = 0;
                                    $totalSubjects = count($subjects);
                                @endphp
                                @foreach($subjects as $subject)
                                    @php
                                        $mark = $marks[$student->id] ?? collect();
                                        $studentMark = $mark->where('subject_id', $subject->id)->first();
                                        $marksObtained = $studentMark ? $studentMark->marks_obtained : '-';
                                        if(is_numeric($marksObtained)) {
                                            $total += $marksObtained;
                                        }
                                    @endphp
                                    <td>{{ $marksObtained }}</td>
                                @endforeach
                                <td>{{ $total }}</td>
                                <td>
                                    @if($totalSubjects > 0)
                                        {{ number_format($total / $totalSubjects, 2) }}
                                    @else
                                        -
                                    @endif
                                </td>
                                <td>
                                    @php
                                        $average = $totalSubjects > 0 ? $total / $totalSubjects : 0;
                                        if ($average >= 90) $grade = 'A+';
                                        elseif ($average >= 80) $grade = 'A';
                                        elseif ($average >= 70) $grade = 'B+';
                                        elseif ($average >= 60) $grade = 'B';
                                        elseif ($average >= 50) $grade = 'C+';
                                        elseif ($average >= 40) $grade = 'C';
                                        else $grade = 'F';
                                    @endphp
                                    {{ $grade }}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
    @media print {
        .btn { display: none; }
        .card { border: none; }
        .card-header { background: none; }
    }
</style>
@endpush
@endsection
