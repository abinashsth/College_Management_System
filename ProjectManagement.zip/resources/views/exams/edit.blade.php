@extends('layouts.app')

@section('content')
<div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200">
                <div class="mb-6">
                    <div class="flex items-center justify-between">
                        <h2 class="text-2xl font-semibold text-gray-800">Edit Exam</h2>
                        <a href="{{ route('exams.index') }}" class="inline-flex items-center px-4 py-2 bg-gray-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring ring-gray-300 disabled:opacity-25 transition ease-in-out duration-150">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 17l-5-5m0 0l5-5m-5 5h12"/>
                            </svg>
                            Back to List
                        </a>
                    </div>
                </div>

                <form action="{{ route('exams.update', $exam->id) }}" method="POST" class="space-y-6">
                    @csrf
                    @method('PUT')

                    <!-- Exam Name and Term -->
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="name" class="block text-sm font-medium text-gray-700 required">Exam Name</label>
                            <div class="mt-1">
                                <input type="text" name="name" id="name" value="{{ old('name', $exam->name) }}" 
                                    class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('name') border-red-500 @enderror" 
                                    placeholder="Enter exam name">
                            </div>
                            @error('name')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <div>
                            <label for="term" class="block text-sm font-medium text-gray-700 required">Term</label>
                            <div class="mt-1">
                                <select name="term" id="term" 
                                    class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('term') border-red-500 @enderror">
                                    <option value="">Select Term</option>
                                    <option value="First Term" {{ old('term', $exam->term) == 'First Term' ? 'selected' : '' }}>First Term</option>
                                    <option value="Second Term" {{ old('term', $exam->term) == 'Second Term' ? 'selected' : '' }}>Second Term</option>
                                    <option value="Third Term" {{ old('term', $exam->term) == 'Third Term' ? 'selected' : '' }}>Third Term</option>
                                </select>
                            </div>
                            @error('term')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>

                    <!-- Session and Dates -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <!-- Session -->
                        <div>
                            <label for="academic_session_id" class="block text-sm font-medium text-gray-700 required">Academic Session</label>
                            <div class="mt-1">
                                <select name="academic_session_id" id="academic_session_id" 
                                    class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('academic_session_id') border-red-500 @enderror">
                                    <option value="">Select Session</option>
                                    @foreach(App\Models\AcademicSession::orderBy('name', 'desc')->get() as $session)
                                        <option value="{{ $session->id }}" 
                                            {{ old('academic_session_id', $exam->academic_session_id) == $session->id ? 'selected' : '' }}>
                                            {{ $session->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                            @error('academic_session_id')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- Start Date -->
                        <div>
                            <label for="start_date" class="block text-sm font-medium text-gray-700 required">Start Date</label>
                            <div class="mt-1">
                                <input type="date" name="start_date" id="start_date" 
                                    value="{{ old('start_date', $exam->start_date?->format('Y-m-d')) }}" 
                                    class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('start_date') border-red-500 @enderror">
                            </div>
                            @error('start_date')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>

                        <!-- End Date -->
                        <div>
                            <label for="end_date" class="block text-sm font-medium text-gray-700 required">End Date</label>
                            <div class="mt-1">
                                <input type="date" name="end_date" id="end_date" 
                                    value="{{ old('end_date', $exam->end_date?->format('Y-m-d')) }}" 
                                    class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('end_date') border-red-500 @enderror">
                            </div>
                            @error('end_date')
                                <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                            @enderror
                        </div>
                    </div>

                    <!-- Description -->
                    <div>
                        <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                        <div class="mt-1">
                            <textarea name="description" id="description" rows="4" 
                                class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('description') border-red-500 @enderror" 
                                placeholder="Enter exam description">{{ old('description', $exam->description) }}</textarea>
                        </div>
                        @error('description')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Submit Button -->
                    <div class="flex justify-end pt-6">
                        <button type="submit" 
                            class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:border-indigo-900 focus:ring ring-indigo-300 disabled:opacity-25 transition ease-in-out duration-150">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                            </svg>
                            Update Exam
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
    .required:after {
        content: " *";
        color: #EF4444;
    }
</style>
@endpush

@push('scripts')
<script>
    // Date validation
    document.getElementById('end_date').addEventListener('change', function() {
        const startDate = document.getElementById('start_date').value;
        const endDate = this.value;
        
        if (startDate && endDate && new Date(endDate) < new Date(startDate)) {
            alert('End date cannot be earlier than start date');
            this.value = '';
        }
    });
</script>
@endpush
@endsection
