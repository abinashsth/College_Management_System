@extends('layouts.app')

@section('content')
<div class="py-6">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
            <div class="p-6 bg-white border-b border-gray-200">
                <div class="mb-6">
                    <h2 class="text-2xl font-semibold text-gray-800">Manage System Settings</h2>
                </div>

                @if(session('success'))
                    <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded">
                        {{ session('success') }}
                    </div>
                @endif

                <form action="{{ route('settings.update') }}" method="POST" class="space-y-6">
                    @csrf
                    @method('PUT')

                    <!-- School Name -->
                    <div>
                        <label for="school_name" class="block text-sm font-medium text-gray-700 required">School Name</label>
                        <div class="mt-1">
                            <input type="text" name="school_name" id="school_name" 
                                value="{{ old('school_name', $setting->school_name) }}"
                                class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('school_name') border-red-500 @enderror">
                        </div>
                        @error('school_name')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- School Acronym -->
                    <div>
                        <label for="school_acronym" class="block text-sm font-medium text-gray-700">School Acronym</label>
                        <div class="mt-1">
                            <input type="text" name="school_acronym" id="school_acronym" 
                                value="{{ old('school_acronym', $setting->school_acronym) }}"
                                class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('school_acronym') border-red-500 @enderror">
                        </div>
                        @error('school_acronym')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Current Session -->
                    <div>
                        <label for="current_session" class="block text-sm font-medium text-gray-700 required">Current Session</label>
                        <div class="mt-1">
                            <select name="current_session" id="current_session"
                                class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('current_session') border-red-500 @enderror">
                                @php
                                    $currentYear = date('Y');
                                    $years = range($currentYear - 1, $currentYear + 2);
                                @endphp
                                @foreach($years as $year)
                                    <option value="{{ $year }}-{{ $year + 1 }}" 
                                        {{ old('current_session', $setting->current_session) == "$year-".($year + 1) ? 'selected' : '' }}>
                                        {{ $year }}-{{ $year + 1 }}
                                    </option>
                                @endforeach
                            </select>
                        </div>
                        @error('current_session')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Phone -->
                    <div>
                        <label for="phone" class="block text-sm font-medium text-gray-700">Phone</label>
                        <div class="mt-1">
                            <input type="text" name="phone" id="phone" 
                                value="{{ old('phone', $setting->phone) }}"
                                class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('phone') border-red-500 @enderror">
                        </div>
                        @error('phone')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Email -->
                    <div>
                        <label for="email" class="block text-sm font-medium text-gray-700">School Email</label>
                        <div class="mt-1">
                            <input type="email" name="email" id="email" 
                                value="{{ old('email', $setting->email) }}"
                                class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('email') border-red-500 @enderror">
                        </div>
                        @error('email')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Address -->
                    <div>
                        <label for="address" class="block text-sm font-medium text-gray-700 required">School Address</label>
                        <div class="mt-1">
                            <textarea name="address" id="address" rows="3"
                                class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('address') border-red-500 @enderror">{{ old('address', $setting->address) }}</textarea>
                        </div>
                        @error('address')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Term End Date -->
                    <div>
                        <label for="term_ends" class="block text-sm font-medium text-gray-700 required">This Term Ends</label>
                        <div class="mt-1">
                            <input type="date" name="term_ends" id="term_ends" 
                                value="{{ old('term_ends', $setting->term_ends?->format('Y-m-d')) }}"
                                class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('term_ends') border-red-500 @enderror">
                        </div>
                        @error('term_ends')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Next Term Start Date -->
                    <div>
                        <label for="next_term_begins" class="block text-sm font-medium text-gray-700 required">Next Term Begins</label>
                        <div class="mt-1">
                            <input type="date" name="next_term_begins" id="next_term_begins" 
                                value="{{ old('next_term_begins', $setting->next_term_begins?->format('Y-m-d')) }}"
                                class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border-gray-300 rounded-md @error('next_term_begins') border-red-500 @enderror">
                        </div>
                        @error('next_term_begins')
                            <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                        @enderror
                    </div>

                    <!-- Exam Lock -->
                    <div class="flex items-center">
                        <input type="checkbox" name="exam_lock" id="exam_lock" 
                            value="1" {{ old('exam_lock', $setting->exam_lock) ? 'checked' : '' }}
                            class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                        <label for="exam_lock" class="ml-2 block text-sm text-gray-700">
                            Lock Exam Results
                            <span class="text-xs text-gray-500">(PIN will be required to view results if enabled)</span>
                        </label>
                    </div>

                    <!-- Submit Button -->
                    <div class="flex justify-end pt-6">
                        <button type="submit" 
                            class="inline-flex items-center px-4 py-2 bg-indigo-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-indigo-700 active:bg-indigo-900 focus:outline-none focus:border-indigo-900 focus:ring ring-indigo-300 disabled:opacity-25 transition ease-in-out duration-150">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                            </svg>
                            Update Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@push('styles')
<style>
    .required:after {
        content: " *";
        color: #EF4444;
    }
</style>
@endpush

@push('scripts')
<script>
    // Date validation
    document.getElementById('next_term_begins').addEventListener('change', function() {
        const termEnds = document.getElementById('term_ends').value;
        const nextTermBegins = this.value;
        
        if (termEnds && nextTermBegins && new Date(nextTermBegins) < new Date(termEnds)) {
            alert('Next term begin date cannot be earlier than term end date');
            this.value = '';
        }
    });
</script>
@endpush
@endsection
