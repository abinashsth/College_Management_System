@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">Exam Session Details</h5>
                </div>

                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6>Session Information</h6>
                            <table class="table table-bordered">
                                <tr>
                                    <th>Name:</th>
                                    <td>{{ $examSession->name }}</td>
                                </tr>
                                <tr>
                                    <th>Faculty:</th>
                                    <td>{{ $examSession->faculty->name }}</td>
                                </tr>
                                <tr>
                                    <th>Start Date:</th>
                                    <td>{{ $examSession->start_date }}</td>
                                </tr>
                                <tr>
                                    <th>End Date:</th>
                                    <td>{{ $examSession->end_date }}</td>
                                </tr>
                                <tr>
                                    <th>Status:</th>
                                    <td>
                                        <span class="badge bg-{{ $examSession->status === 'active' ? 'success' : 'secondary' }}">
                                            {{ ucfirst($examSession->status) }}
                                        </span>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    @can('enter marks')
                    <div class="row mb-4">
                        <div class="col-12">
                            <h6>Enter Marks</h6>
                            <form action="{{ route('marks.store') }}" method="POST">
                                @csrf
                                <input type="hidden" name="exam_session_id" value="{{ $examSession->id }}">
                                
                                <div class="mb-3">
                                    <label for="student_id" class="form-label">Student</label>
                                    <select class="form-select @error('student_id') is-invalid @enderror" 
                                            id="student_id" name="student_id" required>
                                        <option value="">Select Student</option>
                                        @foreach($students as $student)
                                            <option value="{{ $student->id }}">
                                                {{ $student->name }} - {{ $student->roll_number }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="subject_id" class="form-label">Subject</label>
                                    <select class="form-select @error('subject_id') is-invalid @enderror" 
                                            id="subject_id" name="subject_id" required>
                                        <option value="">Select Subject</option>
                                        @foreach($subjects as $subject)
                                            <option value="{{ $subject->id }}" 
                                                    data-full-marks="{{ $subject->full_marks }}"
                                                    data-pass-marks="{{ $subject->pass_marks }}">
                                                {{ $subject->name }} ({{ $subject->code }})
                                            </option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label for="marks_obtained" class="form-label">Marks Obtained</label>
                                    <input type="number" step="0.01" class="form-control @error('marks_obtained') is-invalid @enderror" 
                                           id="marks_obtained" name="marks_obtained" required>
                                    <small class="form-text text-muted">
                                        Full Marks: <span id="full_marks">-</span>, 
                                        Pass Marks: <span id="pass_marks">-</span>
                                    </small>
                                </div>

                                <button type="submit" class="btn btn-primary">Save Marks</button>
                            </form>
                        </div>
                    </div>
                    @endcan

                    <div class="row">
                        <div class="col-12">
                            <h6>Marks Summary</h6>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Student</th>
                                            <th>Roll Number</th>
                                            @foreach($subjects as $subject)
                                                <th>{{ $subject->name }}</th>
                                            @endforeach
                                            <th>Total</th>
                                            <th>Percentage</th>
                                            <th>Result</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($students as $student)
                                            <tr>
                                                <td>{{ $student->name }}</td>
                                                <td>{{ $student->roll_number }}</td>
                                                @php
                                                    $total = 0;
                                                    $totalFullMarks = 0;
                                                    $hasFailed = false;
                                                @endphp
                                                @foreach($subjects as $subject)
                                                    @php
                                                        $mark = $examSession->marks
                                                            ->where('student_id', $student->id)
                                                            ->where('subject_id', $subject->id)
                                                            ->first();
                                                        $totalFullMarks += $subject->full_marks;
                                                        if($mark) {
                                                            $total += $mark->marks_obtained;
                                                            if($mark->marks_obtained < $subject->pass_marks) {
                                                                $hasFailed = true;
                                                            }
                                                        }
                                                    @endphp
                                                    <td>
                                                        {{ $mark ? $mark->marks_obtained : '-' }}
                                                    </td>
                                                @endforeach
                                                <td>{{ $total }}</td>
                                                <td>
                                                    @if($totalFullMarks > 0)
                                                        {{ number_format(($total / $totalFullMarks) * 100, 2) }}%
                                                    @else
                                                        -
                                                    @endif
                                                </td>
                                                <td>
                                                    @if($hasFailed)
                                                        <span class="badge bg-danger">Failed</span>
                                                    @else
                                                        <span class="badge bg-success">Passed</span>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.getElementById('subject_id').addEventListener('change', function() {
    const option = this.options[this.selectedIndex];
    document.getElementById('full_marks').textContent = option.dataset.fullMarks || '-';
    document.getElementById('pass_marks').textContent = option.dataset.passMarks || '-';
});
</script>
@endpush
@endsection
