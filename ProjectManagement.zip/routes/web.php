<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\RoleController;
use App\Http\Controllers\PermissionController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\ClassController;
use App\Http\Controllers\ExamController;
use App\Http\Controllers\ExamTypeController;
use App\Http\Controllers\SubjectController;
use App\Http\Controllers\ResultController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\AcademicSessionController;
use App\Http\Controllers\ExamResultController;
use App\Http\Controllers\ExaminerAssignmentController;
use App\Http\Controllers\MarksEntryController;
use App\Http\Controllers\StudentAdmissionController;
use App\Http\Controllers\GradeController;
use App\Http\Controllers\TabulationController;
use App\Http\Controllers\BatchController;
use App\Http\Controllers\MarkController;
use App\Http\Controllers\MarksheetController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\ExamSessionController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('auth.login');
});

Route::middleware(['auth', 'verified'])->group(function () {
    // Dashboard
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

    // Student Management
    Route::middleware(['permission:view students'])->group(function () {
        Route::resource('students', StudentController::class);
    });

    // Student Admission Routes
    Route::middleware(['permission:view students'])->group(function () {
        Route::get('/students/admit', [StudentAdmissionController::class, 'create'])->name('students.admit');
        Route::post('/students', [StudentAdmissionController::class, 'store'])->name('students.store');
    });

    // Class Management
    Route::middleware(['permission:view classes'])->group(function () {
        Route::resource('classes', ClassController::class);
    });

    // Grade Management Routes
    Route::middleware(['permission:view exams'])->group(function () {
        Route::get('/grades', [GradeController::class, 'index'])->name('grades.index');
        Route::get('/grades/create', [GradeController::class, 'create'])->name('grades.create');
        Route::post('/grades', [GradeController::class, 'store'])->name('grades.store');
        Route::get('/grades/{grade}/edit', [GradeController::class, 'edit'])->name('grades.edit');
        Route::put('/grades/{grade}', [GradeController::class, 'update'])->name('grades.update');
        Route::delete('/grades/{grade}', [GradeController::class, 'destroy'])->name('grades.destroy');
    });

    // Exam Sessions
    Route::middleware(['permission:manage exam sessions'])->group(function () {
        Route::resource('exam-sessions', ExamSessionController::class);
    });

    // Exams
    Route::middleware(['permission:view exams'])->group(function () {
        Route::resource('exams', ExamController::class);
        
        // Tabulation Sheet
        Route::get('/tabulation', [TabulationController::class, 'index'])->name('tabulation.index');
        Route::post('/tabulation/generate', [TabulationController::class, 'generate'])->name('tabulation.generate');
    });

    // Marks
    Route::middleware(['permission:enter marks'])->group(function () {
        Route::post('/marks', [MarkController::class, 'store'])->name('marks.store');
        Route::put('/marks/{mark}', [MarkController::class, 'update'])->name('marks.update');
        Route::delete('/marks/{mark}', [MarkController::class, 'destroy'])->name('marks.destroy');
    });

    // Exam Management Routes
    Route::middleware(['auth', 'role:admin'])->group(function () {
        Route::resource('subjects', SubjectController::class);
        
        // Mark Management
        Route::get('marks/{examSession}/input', [MarkController::class, 'inputForm'])->name('marks.input-form');
        
        // Results
        Route::get('results/faculty/{faculty}', [ResultController::class, 'facultyResults'])->name('results.faculty');
        Route::get('results/student/{student}', [ResultController::class, 'studentResults'])->name('results.student');
    });

    // Result Management Routes
    Route::middleware(['auth'])->group(function () {
        // Add Subjects to Class
        Route::get('/class/add-subjects', [ResultController::class, 'addSubjectsForm'])->name('class.add-subjects.form');
        Route::post('/class/{classId}/add-subjects', [ResultController::class, 'addSubjectsToClass'])->name('class.add-subjects');
        
        // Marks Management
        Route::get('/marks/add', [ResultController::class, 'addMarksForm'])->name('marks.add.form');
        Route::post('/marks/add', [ResultController::class, 'addMarks'])->name('marks.add');
        
        // Marksheets
        Route::get('/marksheet/student/{studentId}', [ResultController::class, 'generateStudentMarksheet'])->name('marksheet.student');
        Route::get('/marksheet/class/{classId}', [ResultController::class, 'generateClassMarksheet'])->name('marksheet.class');
        
        // Settings Management
        Route::get('/settings', [SettingController::class, 'index'])->name('settings.index');
        Route::put('/settings', [SettingController::class, 'update'])->name('settings.update');
    });

    // Result Management
    Route::middleware(['permission:view results'])->group(function () {
        Route::prefix('results')->name('results.')->group(function () {
            // Admin Routes
            Route::middleware(['role:super-admin|admin'])->group(function () {
                Route::get('/publish', [ResultController::class, 'publishIndex'])->name('publish');
                Route::post('/publish/{exam}', [ResultController::class, 'publishResults'])->name('publish-exam');
                Route::get('/classes', [ResultController::class, 'classesIndex'])->name('classes');
                Route::get('/analysis', [ResultController::class, 'analysisIndex'])->name('analysis');
            });

            // Examiner Routes
            Route::middleware(['role:examiner'])->group(function () {
                Route::get('/my-classes', [ResultController::class, 'myClassesIndex'])->name('my-classes');
                Route::get('/my-subjects', [ResultController::class, 'mySubjectsIndex'])->name('my-subjects');
            });

            // Student Routes
            Route::middleware(['role:student'])->group(function () {
                Route::get('/view', [ResultController::class, 'viewResults'])->name('view');
                Route::get('/download', [ResultController::class, 'downloadMarksheet'])->name('download');
            });
        });
    });

    // Report Management
    Route::middleware(['permission:view reports'])->group(function () {
        Route::prefix('reports')->name('reports.')->group(function () {
            Route::get('/students', [ReportController::class, 'studentReport'])->name('students');
            Route::get('/classes', [ReportController::class, 'classIndex'])->name('classes');
            Route::get('/class/{class}', [ReportController::class, 'classReport'])->name('class');
            Route::get('/subjects', [ReportController::class, 'subjectIndex'])->name('subjects');
            Route::get('/subject/{subject}', [ReportController::class, 'subjectShow'])->name('subject.show');
            Route::get('/exams', [ReportController::class, 'examIndex'])->name('exams');
            Route::get('/exam/{exam}', [ReportController::class, 'examShow'])->name('exam.show');
            
            // Download Reports
            Route::get('/download/student/{student}', [ReportController::class, 'downloadStudentReport'])->name('download.student');
            Route::get('/download/class/{class}', [ReportController::class, 'downloadClassReport'])->name('download.class');
            Route::get('/download/subject/{subject}', [ReportController::class, 'downloadSubjectReport'])->name('download.subject');
            Route::get('/download/exam/{exam}', [ReportController::class, 'downloadExamReport'])->name('download.exam');
        });
    });

    // Account Management
    Route::middleware(['permission:view accounts'])->group(function () {
        Route::resource('accounts', AccountController::class);
    });

    // User Management
    Route::middleware(['permission:view users'])->group(function () {
        Route::resource('users', UserController::class);
        Route::get('/change-password', [UserController::class, 'showChangePasswordForm'])->name('change.password.form');
        Route::post('/change-password', [UserController::class, 'changePassword'])->name('change.password');
    });

    // Role Management
    Route::middleware(['permission:view roles'])->group(function () {
        Route::resource('roles', RoleController::class);
    });

    // Permission Management
    Route::middleware(['permission:view permissions'])->group(function () {
        Route::resource('permissions', PermissionController::class);
    });

    // Profile Routes
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
