<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Grade Management</h5>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create grades')): ?>
            <a href="<?php echo e(route('grades.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add New Grade
            </a>
            <?php endif; ?>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Grade Name</th>
                            <th>Point</th>
                            <th>Mark From</th>
                            <th>Mark To</th>
                            <th>Comment</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $grades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($grade->name); ?></td>
                            <td><?php echo e($grade->point); ?></td>
                            <td><?php echo e($grade->mark_from); ?></td>
                            <td><?php echo e($grade->mark_to); ?></td>
                            <td><?php echo e($grade->comment); ?></td>
                            <td>
                                <div class="btn-group">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit grades')): ?>
                                    <a href="<?php echo e(route('grades.edit', $grade)); ?>" class="btn btn-sm btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete grades')): ?>
                                    <form action="<?php echo e(route('grades.destroy', $grade)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">No grades found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\ABC\ProjectManagement\resources\views/exams/grades/index.blade.php ENDPATH**/ ?>