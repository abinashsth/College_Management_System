<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function index()
    {
        $setting = Setting::first() ?? new Setting();
        return view('settings.index', compact('setting'));
    }

    public function update(Request $request)
    {
        $request->validate([
            'school_name' => 'required|string|max:255',
            'school_acronym' => 'required|string|max:10',
            'current_session' => 'required|string',
            'phone' => 'nullable|string|max:20',
            'email' => 'nullable|email|max:255',
            'address' => 'required|string',
            'term_ends' => 'required|date',
            'next_term_begins' => 'required|date|after_or_equal:term_ends',
            'exam_lock' => 'boolean'
        ]);

        $setting = Setting::first() ?? new Setting();
        $setting->fill($request->all());
        $setting->save();

        return redirect()->back()->with('success', 'Settings updated successfully!');
    }
}
