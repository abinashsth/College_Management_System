<?php

namespace App\Http\Controllers;

use App\Models\ExamSession;
use App\Models\Mark;
use App\Models\Exam;
use App\Models\Classes;
use Illuminate\Http\Request;

class MarkController extends Controller
{
    public function index()
    {
        $exams = Exam::all();
        $classes = Classes::all();
        return view('exams.marks.index', compact('exams', 'classes'));
    }

    public function inputForm(ExamSession $examSession)
    {
        $students = $examSession->faculty->students;
        $subjects = $examSession->faculty->subjects;
        
        return view('marks.input', compact('examSession', 'students', 'subjects'));
    }

    public function store(Request $request, ExamSession $examSession)
    {
        $validated = $request->validate([
            'marks.*.student_id' => 'required|exists:students,id',
            'marks.*.subject_id' => 'required|exists:subjects,id',
            'marks.*.marks_obtained' => 'required|numeric|min:0|max:100',
        ]);

        foreach ($request->marks as $mark) {
            Mark::updateOrCreate(
                [
                    'student_id' => $mark['student_id'],
                    'subject_id' => $mark['subject_id'],
                    'exam_session_id' => $examSession->id,
                ],
                ['marks_obtained' => $mark['marks_obtained']]
            );
        }

        return redirect()->back()->with('success', 'Marks saved successfully');
    }
}
