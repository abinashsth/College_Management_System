<?php

namespace App\Http\Controllers;

use App\Models\Exam;
use App\Models\Setting;
use App\Models\AcademicSession;
use Illuminate\Http\Request;

class ExamController extends Controller
{
    public function index(Request $request)
    {
        $setting = Setting::first();
        
        // Get available academic sessions
        $sessions = AcademicSession::orderBy('name', 'desc')->get();
        $currentSessionId = $request->academic_session_id ?? optional($setting)->current_session;

        $exams = Exam::when($request->academic_session_id, function($query, $sessionId) {
                return $query->where('academic_session_id', $sessionId);
            }, function($query) use ($currentSessionId) {
                return $query->where('academic_session_id', $currentSessionId);
            })
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return view('exams.index', compact('exams', 'sessions', 'currentSessionId'));
    }

    public function create()
    {
        return view('exams.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'term' => 'required|string|max:255',
            'academic_session_id' => 'required|exists:academic_sessions,id',
        ]);

        Exam::create($validated);

        return redirect()->route('exams.index')
            ->with('success', 'Exam created successfully.');
    }

    public function edit(Exam $exam)
    {
        return view('exams.edit', compact('exam'));
    }

    public function update(Request $request, Exam $exam)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'term' => 'required|string|max:255',
            'academic_session_id' => 'required|exists:academic_sessions,id',
        ]);

        $exam->update($validated);

        return redirect()->route('exams.index')
            ->with('success', 'Exam updated successfully.');
    }

    public function destroy(Exam $exam)
    {
        $exam->delete();

        return redirect()->route('exams.index')
            ->with('success', 'Exam deleted successfully.');
    }

    public function assignSubjects(Request $request, Exam $exam)
    {
        $validated = $request->validate([
            'subjects' => 'required|array',
            'subjects.*' => 'exists:subjects,id'
        ]);

        $exam->subjects()->sync($request->subjects);

        return back()->with('success', 'Subjects assigned successfully.');
    }

    public function publish(Exam $exam)
    {
        $exam->update(['is_published' => true]);

        return back()->with('success', 'Exam published successfully.');
    }
}
