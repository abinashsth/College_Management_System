<?php

namespace App\Http\Controllers;

use App\Models\Exam;
use App\Models\Classes;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Mark;
use Illuminate\Http\Request;

class TabulationController extends Controller
{
    public function index()
    {
        $exams = Exam::all();
        $classes = Classes::all();
        return view('exams.tabulation.index', compact('exams', 'classes'));
    }

    public function generate(Request $request)
    {
        $request->validate([
            'exam_id' => 'required|exists:exams,id',
            'class_id' => 'required|exists:classes,id',
        ]);

        $exam = Exam::findOrFail($request->exam_id);
        $class = Classes::findOrFail($request->class_id);
        
        // Get all students in the class
        $students = Student::where('class_id', $class->id)->get();
        
        // Get all subjects for the class
        $subjects = Subject::where('class_id', $class->id)->get();
        
        // Get marks for all students
        $marks = Mark::where('exam_id', $exam->id)
            ->whereIn('student_id', $students->pluck('id'))
            ->get()
            ->groupBy('student_id');
        
        return view('exams.tabulation.show', compact('exam', 'class', 'students', 'subjects', 'marks'));
    }
}
