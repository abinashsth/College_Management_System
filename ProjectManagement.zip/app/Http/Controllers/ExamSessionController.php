<?php

namespace App\Http\Controllers;

use App\Models\ExamSession;
use App\Models\Faculty;
use App\Models\Student;
use App\Models\Subject;
use Illuminate\Http\Request;

class ExamSessionController extends Controller
{
    public function index()
    {
        $examSessions = ExamSession::with('faculty')->latest()->paginate(10);
        return view('exam-sessions.index', compact('examSessions'));
    }

    public function create()
    {
        $faculties = Faculty::all();
        return view('exam-sessions.create', compact('faculties'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'faculty_id' => 'required|exists:faculties,id',
            'status' => 'required|in:active,inactive'
        ]);

        ExamSession::create($validated);

        return redirect()->route('exam-sessions.index')
            ->with('success', 'Exam session created successfully.');
    }

    public function show(ExamSession $examSession)
    {
        $examSession->load(['faculty', 'marks.student', 'marks.subject']);
        $students = Student::where('faculty_id', $examSession->faculty_id)->get();
        $subjects = Subject::where('faculty_id', $examSession->faculty_id)->get();
        
        return view('exam-sessions.show', compact('examSession', 'students', 'subjects'));
    }

    public function edit(ExamSession $examSession)
    {
        $faculties = Faculty::all();
        return view('exam-sessions.edit', compact('examSession', 'faculties'));
    }

    public function update(Request $request, ExamSession $examSession)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after:start_date',
            'faculty_id' => 'required|exists:faculties,id',
            'status' => 'required|in:active,inactive'
        ]);

        $examSession->update($validated);

        return redirect()->route('exam-sessions.index')
            ->with('success', 'Exam session updated successfully.');
    }

    public function destroy(ExamSession $examSession)
    {
        $examSession->delete();

        return redirect()->route('exam-sessions.index')
            ->with('success', 'Exam session deleted successfully.');
    }
}
