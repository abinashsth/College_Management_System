<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Exam extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'term',
        'session',
        'is_published'
    ];

    protected $casts = [
        'is_published' => 'boolean',
    ];

    public function subjects()
    {
        return $this->belongsToMany(Subject::class, 'exam_subject')
            ->withTimestamps();
    }
}
