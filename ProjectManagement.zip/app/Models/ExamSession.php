<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ExamSession extends Model
{
    protected $fillable = ['name', 'start_date', 'end_date', 'faculty_id', 'status'];

    public function faculty()
    {
        return $this->belongsTo(Faculty::class);
    }

    public function marks()
    {
        return $this->hasMany(Mark::class);
    }
} 