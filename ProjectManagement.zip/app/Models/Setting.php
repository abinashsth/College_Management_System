<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model
{
    protected $fillable = [
        'school_name',
        'school_acronym',
        'current_session',
        'phone',
        'email',
        'address',
        'term_ends',
        'next_term_begins',
        'exam_lock'
    ];

    protected $casts = [
        'term_ends' => 'date',
        'next_term_begins' => 'date',
        'exam_lock' => 'boolean'
    ];
}
